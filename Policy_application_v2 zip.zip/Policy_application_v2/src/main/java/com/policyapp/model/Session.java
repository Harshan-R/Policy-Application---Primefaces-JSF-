package com.policyapp.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class Session {

    private int id;
    private int userId;
    private Timestamp loginTime;
    private Timestamp logoutTime;
    private AdminUser user;

    // Constructors
    public Session() {
    }

    public Session(int userId, Timestamp loginTime, Timestamp logoutTime) {
        this.userId = userId;
        this.loginTime = loginTime;
        this.logoutTime = logoutTime;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Timestamp getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Timestamp loginTime) {
        this.loginTime = loginTime;
    }

    public Timestamp getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(Timestamp logoutTime) {
        this.logoutTime = logoutTime;
    }

    public AdminUser getUser() {
        return user;
    }

    public void setUser(AdminUser user) {
        this.user = user;
    }

    // Transient methods

    public String getUsername() {
        return user != null ? user.getUsername() : null;
    }

    public String getRole() {
        return user != null ? user.getRole().name() : null;
    }

    // JDBC operations

    // Save session to the database
    public void save(Connection conn) throws SQLException {
        String sql = "INSERT INTO sessions (user_id, login_time, logout_time) VALUES (?, ?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, userId);
            statement.setTimestamp(2, loginTime);
            statement.setTimestamp(3, logoutTime);

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating session failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    id = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating session failed, no ID obtained.");
                }
            }
        }
    }

    // Retrieve session from the database by session ID
    public static Session getById(Connection conn, int sessionId) throws SQLException {
        String sql = "SELECT * FROM sessions WHERE id = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, sessionId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Session session = new Session();
                    session.setId(resultSet.getInt("id"));
                    session.setUserId(resultSet.getInt("user_id"));
                    session.setLoginTime(resultSet.getTimestamp("login_time"));
                    session.setLogoutTime(resultSet.getTimestamp("logout_time"));
                    return session;
                }
            }
        }
        return null;
    }
}
