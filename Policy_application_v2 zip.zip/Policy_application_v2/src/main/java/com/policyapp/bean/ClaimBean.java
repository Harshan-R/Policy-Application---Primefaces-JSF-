package com.policyapp.bean;

import com.policyapp.dao.ClaimDao;
import com.policyapp.model.Claim;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
@Getter
@Setter
public class ClaimBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Claim> claims;
    private List<Claim> filteredClaims;
    public List<Claim> getClaims() {
		return claims;
	}

	public void setClaims(List<Claim> claims) {
		this.claims = claims;
	}

	public List<Claim> getFilteredClaims() {
		return filteredClaims;
	}

	public void setFilteredClaims(List<Claim> filteredClaims) {
		this.filteredClaims = filteredClaims;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public ClaimDao getClaimDao() {
		return claimDao;
	}

	public void setClaimDao(ClaimDao claimDao) {
		this.claimDao = claimDao;
	}

	private String searchBy;
    private String searchText;
    private ClaimDao claimDao;

    @PostConstruct
    public void init() {
        claimDao = new ClaimDao();
        try {
            claims = claimDao.getAllClaims(); // Initialize with all claims
        } catch (SQLException e) {
            e.printStackTrace();
            claims = new ArrayList<>(); // Empty list or default behavior
        }
        filteredClaims = claims; // Initially, show all claims
    }

    public void searchClaims() {
        if (searchText == null || searchText.isEmpty()) {
            filteredClaims = claims; // Show all claims if search text is empty
            return;
        }

        try {
            switch (searchBy) {
                case "ID":
                    filteredClaims = claimDao.getClaimsById(Integer.parseInt(searchText));
                    break;
                case "policy_id":
                    filteredClaims = claimDao.getClaimsByPolicyId(Integer.parseInt(searchText));
                    break;
                case "claim_status":
                    filteredClaims = claimDao.getClaimsByStatus(searchText);
                    break;
                default:
                    filteredClaims = claims; // Show all claims by default
            }
        } catch (SQLException e) {
            e.printStackTrace();
            filteredClaims = new ArrayList<>(); // Empty list or default behavior
        }
    }
}
