package com.policyapp.bean;

import com.policyapp.dao.PolicyDao;
import com.policyapp.model.Policy;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
@Getter
@Setter
public class PolicyBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Policy> policies;
    public List<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	public List<Policy> getFilteredPolicies() {
		return filteredPolicies;
	}

	public void setFilteredPolicies(List<Policy> filteredPolicies) {
		this.filteredPolicies = filteredPolicies;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public PolicyDao getPolicyDao() {
		return policyDao;
	}

	public void setPolicyDao(PolicyDao policyDao) {
		this.policyDao = policyDao;
	}

	private List<Policy> filteredPolicies;
    private String searchBy;
    private String searchText;
    private PolicyDao policyDao;

    @PostConstruct
    public void init() {
        policyDao = new PolicyDao();
        try {
            policies = policyDao.getAllPolicies(); // Initialize with all policies
        } catch (SQLException e) {
            e.printStackTrace();
            policies = new ArrayList<>(); // Empty list or default behavior
        }
        filteredPolicies = policies; // Initially, show all policies
    }

    public void searchPolicies() {
        if (searchText == null || searchText.isEmpty()) {
            filteredPolicies = policies; // Show all policies if search text is empty
            return;
        }

        try {
            switch (searchBy) {
                case "ID":
                    filteredPolicies = policyDao.getPoliciesById(Integer.parseInt(searchText));
                    break;
                case "customer_name":
                    filteredPolicies = policyDao.getPoliciesByCustomerName(searchText);
                    break;
                case "policy_type":
                    filteredPolicies = policyDao.getPoliciesByType(searchText);
                    break;
                case "email":
                    filteredPolicies = policyDao.getPoliciesByEmail(searchText);
                    break;
                default:
                    filteredPolicies = policies; // Show all policies by default
            }
        } catch (SQLException e) {
            e.printStackTrace();
            filteredPolicies = new ArrayList<>(); // Empty list or default behavior
        }
    }
}
