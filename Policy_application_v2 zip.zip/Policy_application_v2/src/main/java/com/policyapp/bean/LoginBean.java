package com.policyapp.bean;

import com.policyapp.dao.UserDao;
import com.policyapp.model.User;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.sql.Timestamp;

@ManagedBean
@SessionScoped
public class LoginBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private String email;
    private User loggedInUser;
    private UserDao userDao = new UserDao();

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    // Actions
    public String login() {
        try {
            loggedInUser = userDao.getUser(username, password);
            if (loggedInUser != null) {
                userDao.logUserSession(loggedInUser.getId(), getCurrentTimestamp()); // Log the user session
                return determineNavigation(loggedInUser.getRole());
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid credentials", null));
                return "login.xhtml";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Database error", null));
            return "login.xhtml";
        }
    }

    public String signUp() {
        try {
            if (userDao.isUsernameTaken(username)) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Username already exists", null));
                return "signup.xhtml";
            } else if (userDao.isEmailTaken(email)) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email already exists", null));
                return "signup.xhtml";
            } else {
                User newUser = new User();
                newUser.setUsername(username);
                newUser.setPassword(password);
                newUser.setEmail(email);
                newUser.setRole("customer");
                userDao.createUser(newUser);
                loggedInUser = newUser; // Automatically log in the new user
                userDao.logUserSession(loggedInUser.getId(), getCurrentTimestamp()); // Log the user session
                return "admin.xhtml?faces-redirect=true"; // Redirect to admin dashboard after signup
            }
        } catch (SQLException e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Database error", null));
            return "signup.xhtml";
        }
    }

    public String logout() {
        try {
            if (loggedInUser != null) {
                userDao.updateLogoutTime(loggedInUser.getId(), getCurrentTimestamp()); // Update logout time
            }
        } catch (SQLException e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Database error", null));
        }
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession(); // Invalidate session
        return "login.xhtml?faces-redirect=true";
    }

    private String determineNavigation(String role) {
        switch (role) {
            case "admin":
                return "admin.xhtml?faces-redirect=true";
            case "agent":
                return "agent.xhtml?faces-redirect=true";
            case "customer":
                return "customer.xhtml?faces-redirect=true";
            default:
                return "login.xhtml";
        }
    }

    private Timestamp getCurrentTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }
}
