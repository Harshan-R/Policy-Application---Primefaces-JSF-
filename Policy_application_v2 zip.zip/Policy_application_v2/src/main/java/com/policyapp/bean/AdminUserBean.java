package com.policyapp.bean;

import com.policyapp.dao.AdminUserDao;
import com.policyapp.dao.SessionDao;
import com.policyapp.model.AdminUser;
import com.policyapp.model.Session;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Named
@ViewScoped
public class AdminUserBean implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
    private AdminUserDao adminUserDao;

    @Inject
    private SessionDao sessionDao;

    private List<Session> filteredSessions;
    private String action;
    private String searchBy;
    private String searchText;

    private AdminUser newUser;

    @PostConstruct
    public void init() {
        newUser = new AdminUser();
    }

    public AdminUser getNewUser() {
        return newUser;
    }

    public void setNewUser(AdminUser newUser) {
        this.newUser = newUser;
    }

    public List<Session> getFilteredSessions() {
        return filteredSessions;
    }

    public void setFilteredSessions(List<Session> filteredSessions) {
        this.filteredSessions = filteredSessions;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getSearchBy() {
        return searchBy;
    }

    public void setSearchBy(String searchBy) {
        this.searchBy = searchBy;
    }

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    public void performAction() {
        try {
            switch (action) {
                case "addUser":
                    addUser();
                    break;
                case "searchSessions":
                    searchSessions();
                    break;
                default:
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning", "Invalid action selected"));
                    break;
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "An unexpected error occurred."));
            e.printStackTrace(); // Log the exception for debugging
        }
    }

    public void addUser() {
        // Check if username or email already exist
        if (adminUserDao.isUsernameOrEmailExist(newUser.getUsername(), newUser.getEmail())) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning", "Username or Email already exists"));
        } else {
            
            newUser.setCreated_date(new Timestamp(System.currentTimeMillis()));

            
            adminUserDao.save(newUser);

            
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "User added successfully"));

            
            newUser = new AdminUser();
        }
    }

    public void searchSessions() {
        if (searchBy == null || searchText == null || searchText.isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning", "Please provide search criteria"));
            return;
        }

        filteredSessions = sessionDao.searchSessions(searchBy, searchText);
    }
}
