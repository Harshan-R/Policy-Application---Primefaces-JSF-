package com.policyapp.bean;

import com.policyapp.dao.UserDao;
import com.policyapp.model.User;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import java.sql.SQLException;

@ManagedBean
@ViewScoped
public class UserBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private String email;
    private String role;

    private UserDao userDAO = new UserDao();

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String login() {
        try {
            User user = userDAO.getUser(username, password);
            if (user != null) {
                role = user.getRole();
                switch (role) {
                    case "admin":
                        return "admin.xhtml?faces-redirect=true";
                    case "agent":
                        return "agent.xhtml?faces-redirect=true";
                    case "customer":
                        return "customer.xhtml?faces-redirect=true";
                    default:
                        return "login.xhtml";
                }
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid credentials", null));
                return "login.xhtml";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Database error", null));
            return "login.xhtml";
        }
    }

    public String signUp() {
        try {
            if (userDAO.isUsernameTaken(username)) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Username already exists", null));
                return "signup.xhtml";
            } else if (userDAO.isEmailTaken(email)) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email already exists", null));
                return "signup.xhtml";
            } else {
                User newUser = new User();
                newUser.setUsername(username);
                newUser.setPassword(password);
                newUser.setEmail(email);
                newUser.setRole("customer");
                userDAO.createUser(newUser);
                return "login.xhtml?faces-redirect=true";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Database error", null));
            return "signup.xhtml";
        }
    }
}
