package com.policyapp.dao;

import com.policyapp.model.AdminUser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdminUserDao {
    private static final Logger logger = Logger.getLogger(AdminUserDao.class.getName());

    // Database connection details
    private final String jdbcURL = "jdbc:mysql://localhost:3306/policy_app_11";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "password";

    // Insert a new user
    public void save(AdminUser user) {
        String sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getPassword());
            statement.setString(4, user.getRole().name());
            statement.executeUpdate();
        } catch (SQLException ex) {
            logger.log(Level.SEVERE, "Error saving user", ex);
        }
    }

    // Check if username or email exists
    public boolean isUsernameOrEmailExist(String username, String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, username);
            statement.setString(2, email);
            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    int count = result.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException ex) {
            logger.log(Level.SEVERE, "Error checking username or email existence", ex);
        }
        return false;
    }
}
