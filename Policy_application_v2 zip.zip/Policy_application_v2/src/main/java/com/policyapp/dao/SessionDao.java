package com.policyapp.dao;

import com.policyapp.model.AdminUser;
import com.policyapp.model.Session;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SessionDao {
    private static final Logger logger = Logger.getLogger(SessionDao.class.getName());

    // Database connection details
    private final String jdbcURL = "jdbc:mysql://localhost:3306/policy_app_11";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "password";

    // Search sessions by various criteria
    public List<Session> searchSessions(String searchBy, String searchText) {
        List<Session> sessions = new ArrayList<>();
        String query = buildQuery(searchBy);

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = conn.prepareStatement(query)) {
            if (searchBy.equals("userId") || searchBy.equals("logoutDate")) {
                statement.setInt(1, Integer.parseInt(searchText));
            } else {
                statement.setString(1, "%" + searchText + "%");
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Session session = new Session();
                    session.setId(resultSet.getInt("id"));
                    session.setUserId(resultSet.getInt("user_id"));
                    session.setLoginTime(resultSet.getTimestamp("login_time"));
                    session.setLogoutTime(resultSet.getTimestamp("logout_time"));

                    // Fetch user details
                    AdminUser user = new AdminUser();
                    user.setId(resultSet.getInt("u.id"));
                    user.setEmail(resultSet.getString("u.email"));
                    user.setUsername(resultSet.getString("u.username"));
                    // Set other user properties as needed

                    session.setUser(user); // Set user object into session

                    sessions.add(session);
                }
            }
        } catch (SQLException ex) {
            logger.log(Level.SEVERE, "Error searching sessions", ex);
        }
        return sessions;
    }

    // Build SQL query based on search criteria
    private String buildQuery(String searchBy) {
        switch (searchBy) {
            case "loginDate":
                return "SELECT s.*, u.* FROM sessions s LEFT JOIN users u ON s.user_id = u.id WHERE s.login_time LIKE ?";
            case "userId":
                return "SELECT s.*, u.* FROM sessions s LEFT JOIN users u ON s.user_id = u.id WHERE s.user_id = ?";
            case "logoutDate":
                return "SELECT s.*, u.* FROM sessions s LEFT JOIN users u ON s.user_id = u.id WHERE s.logout_time LIKE ?";
            case "username":
                return "SELECT s.*, u.* FROM sessions s LEFT JOIN users u ON s.user_id = u.id WHERE u.username LIKE ?";
            default:
                throw new IllegalArgumentException("Invalid search criteria");
        }
    }
}
