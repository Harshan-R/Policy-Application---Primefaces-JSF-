package com.policyapp.dao;

import com.policyapp.model.Policy;
import com.policyapp.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDao {

    public List<Policy> getAllPolicies() throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Policy policy = mapResultSetToPolicy(resultSet);
                policies.add(policy);
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesById(int id) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByCustomerName(String customerName) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE customer_name LIKE ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + customerName + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByType(String policyType) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE policy_type = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, policyType);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByEmail(String email) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE email LIKE ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + email + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    private Policy mapResultSetToPolicy(ResultSet resultSet) throws SQLException {
        Policy policy = new Policy();
        policy.setId(resultSet.getInt("id"));
        policy.setCustomerName(resultSet.getString("customer_name"));
        policy.setDob(resultSet.getDate("dob"));
        policy.setMedicalHistory(resultSet.getBoolean("medical_history"));
        policy.setGender(resultSet.getString("gender"));
        policy.setAddress(resultSet.getString("address"));
        policy.setEmail(resultSet.getString("email"));
        policy.setPhone(resultSet.getString("phone"));
        policy.setPolicyType(resultSet.getString("policy_type"));
        policy.setPolicyStartDate(resultSet.getDate("policy_start_date"));
        policy.setPolicyEndDate(resultSet.getDate("policy_end_date"));
        policy.setCoverage(resultSet.getBigDecimal("coverage"));
        policy.setPremium(resultSet.getBigDecimal("premium"));
        policy.setAgentApproval(resultSet.getString("agent_approval"));
        policy.setCreatedBy(resultSet.getInt("created_by"));
        policy.setCreatedDate(resultSet.getDate("created_date"));
        policy.setUpdatedBy(resultSet.getInt("updated_by"));
        policy.setUpdatedDate(resultSet.getDate("updated_date"));
        return policy;
    }
}
