package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class InsuranceDAO {
    private static final EntityManagerFactory emf;

    static {
        try {
            emf = Persistence.createEntityManagerFactory("insurancePU");
        } catch (Exception ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public void saveInsurance(Insurance insurance) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(insurance);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public List<Insurance> getAllInsurances() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT i FROM Insurance i", Insurance.class).getResultList();
        } finally {
            em.close();
        }
    }
}
