package com.example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name = "productListBean")
@ViewScoped
public class ProductListBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<Product> productList;
    private List<Product> filteredProducts;
    private Long searchProductId;

    // Add ownerId and eventId fields
    private int ownerId;
    private int eventId;
    private int childId;

    public int getChildId() {
        return childId;
    }

    public void setChildId(int childId) {
        this.childId = childId;
    }


    public ProductListBean() {
        productList = new ArrayList<>();
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }

    public List<Product> getFilteredProducts() {
        return filteredProducts;
    }

    public void setFilteredProducts(List<Product> filteredProducts) {
        this.filteredProducts = filteredProducts;
    }

    public Long getSearchProductId() {
        return searchProductId;
    }

    public void setSearchProductId(Long searchProductId) {
        this.searchProductId = searchProductId;
    }

    // Add getters and setters for ownerId and eventId
    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public void searchProducts() {
        productList.clear();
        try (Connection conn = getConnection()) {
            String sql = getQuery();
            System.out.println(sql);
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
               
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        // Assuming the SQL query fetched from the database returns columns
                        // with names similar to the ones used in your original code
                        Product fetchedProduct = new Product();
                        fetchedProduct.setProductId(rs.getLong("PRD_PRODUCT_VER_STATE_ID"));
                        fetchedProduct.setState(rs.getString("STATE"));
                        fetchedProduct.setActive(rs.getString("ACTIVE"));
                        fetchedProduct.setCreatedBy(rs.getString("CREATED_BY"));
                        fetchedProduct.setCreatedDate(rs.getDate("CREATED_DATE"));
                        fetchedProduct.setUpdatedBy(rs.getString("UPDATED_BY"));
                        fetchedProduct.setUpdatedDate(rs.getDate("UPDATED_DATE"));
                        fetchedProduct.setApplicableFromDate(rs.getDate("APPLICABLE_FROM_DATE"));
                        fetchedProduct.setEffectiveDate(rs.getDate("EFFECTIVE_DATE"));
                        fetchedProduct.setExpirationDate(rs.getDate("EXPIRATION_DATE"));
                        productList.add(fetchedProduct);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Define the SQL query using ownerId and eventId
    private String getQuery() {
        String resultQuery = null;
        try (Connection conn = getConnection()) {
        	System.out.println("ownerId "+ownerId);
        	System.out.println("Child Id "+childId);
            String selectQuery = "SELECT os.`SQL` "
                    + "FROM CNF_OBJECT_SCRIPTS os "
                    + "JOIN CNF_GET_DATA_SCRIPTS_ASSTN ass ON os.CNF_OBJECT_SCRIPTS_ID = ass.CNF_OBJECT_SCRIPTS_ID "
                    + "WHERE ass.CNF_GET_DATA_MASTER_ID = ? "
                    + "AND ass.CNF_GET_DATA_CHILD_ID = ?;";
            

            try (PreparedStatement stmt = conn.prepareStatement(selectQuery)) {
                stmt.setInt(1, ownerId);
                stmt.setInt(2, childId);
                System.out.println("Statement "+stmt);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    	System.out.println("Quer" + selectQuery);
                        resultQuery = rs.getString("SQL");
                        
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultQuery;
    }

    // Establish database connection
    private Connection getConnection() throws Exception {
        String jdbcUrl = "jdbc:mysql://localhost:3306/data_retrive"; // Corrected the database name
        String username = "root";
        String password = "password";
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(jdbcUrl, username, password);
    }
}
