package com.example;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class QuizBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<Quiz> questions;
    private int selectedTopicId;
    private int score;
    public int sscore = 110;
    private boolean quizSubmitted;
    private int timer = 120;
    private List<Topic> topics;

    @PostConstruct
    public void init() {
        questions = new ArrayList<>();
        loadTopics();
    }

    public void loadTopics() {
        topics = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM topics");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Topic topic = new Topic();
                topic.setId(rs.getInt("id"));
                topic.setName(rs.getString("name"));
                topics.add(topic);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String loadQuestions() {
        if (selectedTopicId <= 0) {
            return ""; // Or handle error
        }

        questions.clear();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM questions WHERE topic_id = ? ORDER BY RAND() LIMIT 10")) {
            stmt.setInt(1, selectedTopicId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Quiz quiz = new Quiz();
                    quiz.setId(rs.getInt("id"));
                    quiz.setQuestionText(rs.getString("question_text"));
                    quiz.setAnswerA(rs.getString("answer_a"));
                    quiz.setAnswerB(rs.getString("answer_b"));
                    quiz.setAnswerC(rs.getString("answer_c"));
                    quiz.setAnswerD(rs.getString("answer_d"));
                    quiz.setCorrectAnswer(rs.getString("correct_answer").charAt(0));
                    questions.add(quiz);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        quizSubmitted = false;
        score = 0;
        timer = 120;

        // Redirect to quiz.xhtml
        return "quiz?faces-redirect=true";
    }

    public void submitQuiz() {
        quizSubmitted = true;
        for (Quiz q : questions) {
            if (q.getSelectedAnswer() != null && q.getSelectedAnswer().charAt(0) == q.getCorrectAnswer()) {
                score++;
            }
        }
    }

    // Getters and setters

    public List<Quiz> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Quiz> questions) {
        this.questions = questions;
    }

    public int getSelectedTopicId() {
        return selectedTopicId;
    }

    public void setSelectedTopicId(int selectedTopicId) {
        this.selectedTopicId = selectedTopicId;
    }

    public int getScore() {
    	score = Math.min(score, sscore);
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public boolean isQuizSubmitted() {
        return quizSubmitted;
    }

    public void setQuizSubmitted(boolean quizSubmitted) {
        this.quizSubmitted = quizSubmitted;
    }

    public int getTimer() {
        return timer;
    }

    public void setTimer(int timer) {
        this.timer = timer;
    }

    public List<Topic> getTopics() {
        return topics;
    }

    public void setTopics(List<Topic> topics) {
        this.topics = topics;
    }

    // getConnection method
    private Connection getConnection() throws SQLException {
        String jdbcUrl = "jdbc:mysql://localhost:3306/online_learning";
        String username = "root";
        String password = "password";
        return DriverManager.getConnection(jdbcUrl, username, password);
    }
}
