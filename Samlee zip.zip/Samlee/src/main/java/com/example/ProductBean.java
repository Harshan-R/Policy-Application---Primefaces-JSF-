package com.example;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name = "productBean")
@ViewScoped
public class ProductBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private Product product;

    public ProductBean() {
        product = new Product();
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void saveProduct() {
        try (Connection conn = getConnection()) {
        	String sql = getQuery();
            System.out.println(sql);
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, product.getState());
                stmt.setString(2, product.getActive());
                stmt.setString(3, product.getCreatedBy());
                stmt.setDate(4, new java.sql.Date(product.getCreatedDate().getTime()));
                stmt.setString(5, product.getUpdatedBy());
                stmt.setDate(6, new java.sql.Date(product.getUpdatedDate().getTime()));
                stmt.setDate(7, new java.sql.Date(product.getApplicableFromDate().getTime()));
                stmt.setDate(8, new java.sql.Date(product.getEffectiveDate().getTime()));
                stmt.setDate(9, new java.sql.Date(product.getExpirationDate().getTime()));
                int rowsInserted = stmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Product saved successfully!");
                } else {
                    System.out.println("Failed to save product.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private String getQuery() {
        String resultQuery = null;
        try (Connection conn = getConnection()) {
            String selectQuery = "SELECT os.SQL_TEXT FROM CNF_OBJECT_SCRIPTS os JOIN CNF_OBJECT_EVENT_SCRIPTS oes ON os.CNF_OBJECT_SCRIPTS_ID = oes.CNF_OBJECT_SCRIPTS_ID WHERE oes.CNF_OBJECT_EVENT_ID = 1;";
            

            try (PreparedStatement stmt = conn.prepareStatement(selectQuery)) {
                System.out.println("Statement "+stmt);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    	System.out.println("Quer" + selectQuery);
                        resultQuery = rs.getString("SQL_TEXT");
                        
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultQuery;
    }

    private Connection getConnection() throws Exception {
        String jdbcUrl = "jdbc:mysql://localhost:3306/data_saver";
        String username = "root";
        String password = "password";
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(jdbcUrl, username, password);
    }
}
