package com.example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@ManagedBean(name = "insuranceBean2")
@RequestScoped
public class InsuranceBean {
    private Insurance insurance;
    private List<Insurance> insurances;

    public InsuranceBean() {
        insurance = new Insurance();
        insurances = new ArrayList<>();
        loadInsurances(); // Load insurances on bean initialization
    }

    // Getters and setters
    public Insurance getInsurance() {
        return insurance;
    }

    public List<Insurance> getInsurances() {
        return insurances;
    }
    
    public void saveInsurance() {
        try {
        	Insurance ins = new Insurance();
        	System.out.println(insurance.getApplicantName());
            if (insurance.getApplicantName() == null || insurance.getInsuranceType() == null || insurance.getCoverageStart() == null) {
                System.out.println("Please fill out all required fields.");
                return;
            }
            
            String sql = "INSERT INTO insurance_application (applicant_name, insurance_type, premium_amount, coverage_start, additional_info) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, insurance.getApplicantName());
                stmt.setString(2, insurance.getInsuranceType());
                stmt.setDouble(3, insurance.getPremiumAmount());
                stmt.setDate(4, new java.sql.Date(insurance.getCoverageStart().getTime()));
                stmt.setString(5, insurance.getAdditionalInfo());

                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Insurance saved successfully!");
                } else {
                    System.out.println("Failed to save insurance.");
                }

            } catch (Exception e) {
                System.out.println("Error saving insurance: " + e.getMessage());
                e.printStackTrace();
            }
            loadInsurances(); // Update the DataTable after saving
        } catch (Exception ex) {
            System.out.println("Error in saveInsurance(): " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void loadInsurances() {
        String sql = "SELECT * FROM insurance_application";
        insurances.clear();
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Insurance ins = new Insurance();
                ins.setApplicantName(rs.getString("applicant_name"));
                ins.setInsuranceType(rs.getString("insurance_type"));
                ins.setPremiumAmount(rs.getDouble("premium_amount"));
                ins.setCoverageStart(rs.getDate("coverage_start"));
                ins.setAdditionalInfo(rs.getString("additional_info"));
                insurances.add(ins);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        String url = "jdbc:mysql://localhost:3306/insurance_db";
        String username = "root";
        String password = "password";
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, username, password);
    }
}
