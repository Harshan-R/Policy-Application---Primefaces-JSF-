package com.policyapp.bean;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.pie.PieChartDataSet;
import org.primefaces.model.charts.pie.PieChartModel;
import com.policyapp.util.DatabaseUtil;

@ManagedBean(name = "adminStatisticsBean")
@ViewScoped
public class AdminStatisticsBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private int totalUsers;
    private int totalPolicies;
    private double totalCoverage;
    private double totalPremium;
    private int approvedPolicies;
    private int rejectedPolicies;
    private int pendingPolicies;
    private int maleUsers;
    private int femaleUsers;
    private int binaryUsers;
    private String highestClaimMonth;
    private int lifePolicies;
    private int healthPolicies;
    private int autoPolicies;
    private int liabilityPolicies;
    private int homePolicies;

    private PieChartModel policyStatusChart;

    @PostConstruct
    public void init() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            fetchTotalUsers(connection);
            fetchTotalPolicies(connection);
            fetchTotalCoverage(connection);
            fetchTotalPremium(connection);
            fetchPolicyStatuses(connection);
            fetchGenderStatistics(connection);
            fetchPolicyTypes(connection);
            fetchHighestClaimMonth(connection);
            createPolicyStatusChart();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void fetchTotalUsers(Connection connection) throws SQLException {
        String query = "SELECT COUNT(*) FROM users";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                totalUsers = rs.getInt(1);
            }
        }
    }

    private void fetchTotalPolicies(Connection connection) throws SQLException {
        String query = "SELECT COUNT(*) FROM policies";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                totalPolicies = rs.getInt(1);
            }
        }
    }

    private void fetchTotalCoverage(Connection connection) throws SQLException {
        String query = "SELECT SUM(coverage) FROM policies";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                totalCoverage = rs.getDouble(1);
            }
        }
    }

    private void fetchTotalPremium(Connection connection) throws SQLException {
        String query = "SELECT SUM(premium) FROM policies";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                totalPremium = rs.getDouble(1);
            }
        }
    }

    private void fetchPolicyStatuses(Connection connection) throws SQLException {
        String query = "SELECT agent_approval, COUNT(*) FROM policies GROUP BY agent_approval";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String status = rs.getString(1);
                int count = rs.getInt(2);
                switch (status) {
                    case "yes":
                        approvedPolicies = count;
                        break;
                    case "no":
                        rejectedPolicies = count;
                        break;
                    case "pending":
                        pendingPolicies = count;
                        break;
                    default:
                        // Handle any other unexpected cases
                        break;
                }
            }
        }
    }

    private void fetchGenderStatistics(Connection connection) throws SQLException {
        String query = "SELECT gender, COUNT(*) FROM policies GROUP BY gender";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String gender = rs.getString(1);
                int count = rs.getInt(2);
                switch (gender) {
                    case "male":
                        maleUsers = count;
                        break;
                    case "female":
                        femaleUsers = count;
                        break;
                    case "binary":
                        binaryUsers = count;
                        break;
                }
            }
        }
    }

    private void fetchPolicyTypes(Connection connection) throws SQLException {
        String query = "SELECT policy_type, COUNT(*) FROM policies GROUP BY policy_type";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String type = rs.getString(1);
                int count = rs.getInt(2);
                switch (type) {
                    case "Life":
                        lifePolicies = count;
                        break;
                    case "Health":
                        healthPolicies = count;
                        break;
                    case "Auto":
                        autoPolicies = count;
                        break;
                    case "Liability":
                        liabilityPolicies = count;
                        break;
                    case "Home":
                        homePolicies = count;
                        break;
                }
            }
        }
    }

    private void fetchHighestClaimMonth(Connection connection) throws SQLException {
        String query = "SELECT DATE_FORMAT(claim_date, '%Y-%m') as month, COUNT(*) as claim_count " +
                "FROM claims " +
                "GROUP BY month " +
                "ORDER BY claim_count DESC " +
                "LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                highestClaimMonth = rs.getString(1);
            }
        }
    }

    private void createPolicyStatusChart() {
        policyStatusChart = new PieChartModel();
        ChartData data = new ChartData();

        PieChartDataSet dataSet = new PieChartDataSet();
        List<Number> values = new ArrayList<>();
        values.add(approvedPolicies);
        values.add(rejectedPolicies);
        values.add(pendingPolicies);
        dataSet.setData(values);

        List<String> bgColors = Arrays.asList("rgb(75, 192, 192)", "rgb(255, 99, 132)", "rgb(255, 205, 86)");
        dataSet.setBackgroundColor(bgColors);

        data.addChartDataSet(dataSet);

        List<String> labels = Arrays.asList("Approved", "Rejected", "Pending");
        data.setLabels(labels);

        policyStatusChart.setData(data);
    }

    public int getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(int totalUsers) {
        this.totalUsers = totalUsers;
    }

    public int getTotalPolicies() {
        return totalPolicies;
    }

    public void setTotalPolicies(int totalPolicies) {
        this.totalPolicies = totalPolicies;
    }

    public double getTotalCoverage() {
        return totalCoverage;
    }

    public void setTotalCoverage(double totalCoverage) {
        this.totalCoverage = totalCoverage;
    }

    public double getTotalPremium() {
        return totalPremium;
    }

    public void setTotalPremium(double totalPremium) {
        this.totalPremium = totalPremium;
    }

    public int getApprovedPolicies() {
        return approvedPolicies;
    }

    public void setApprovedPolicies(int approvedPolicies) {
        this.approvedPolicies = approvedPolicies;
    }

    public int getRejectedPolicies() {
        return rejectedPolicies;
    }

    public void setRejectedPolicies(int rejectedPolicies) {
        this.rejectedPolicies = rejectedPolicies;
    }

    public int getPendingPolicies() {
        return pendingPolicies;
    }

    public void setPendingPolicies(int pendingPolicies) {
        this.pendingPolicies = pendingPolicies;
    }

    public int getMaleUsers() {
        return maleUsers;
    }

    public void setMaleUsers(int maleUsers) {
        this.maleUsers = maleUsers;
    }

    public int getFemaleUsers() {
        return femaleUsers;
    }

    public void setFemaleUsers(int femaleUsers) {
        this.femaleUsers = femaleUsers;
    }

    public int getBinaryUsers() {
        return binaryUsers;
    }

    public void setBinaryUsers(int binaryUsers) {
        this.binaryUsers = binaryUsers;
    }

    public String getHighestClaimMonth() {
        return highestClaimMonth;
    }

    public void setHighestClaimMonth(String highestClaimMonth) {
        this.highestClaimMonth = highestClaimMonth;
    }

    public int getLifePolicies() {
        return lifePolicies;
    }

    public void setLifePolicies(int lifePolicies) {
        this.lifePolicies = lifePolicies;
    }

    public int getHealthPolicies() {
        return healthPolicies;
    }

    public void setHealthPolicies(int healthPolicies) {
        this.healthPolicies = healthPolicies;
    }

    public int getAutoPolicies() {
        return autoPolicies;
    }

    public void setAutoPolicies(int autoPolicies) {
        this.autoPolicies = autoPolicies;
    }

    public int getLiabilityPolicies() {
        return liabilityPolicies;
    }

    public void setLiabilityPolicies(int liabilityPolicies) {
        this.liabilityPolicies = liabilityPolicies;
    }

    public int getHomePolicies() {
        return homePolicies;
    }

    public void setHomePolicies(int homePolicies) {
        this.homePolicies = homePolicies;
    }

    public PieChartModel getPolicyStatusChart() {
        return policyStatusChart;
    }

    public void setPolicyStatusChart(PieChartModel policyStatusChart) {
        this.policyStatusChart = policyStatusChart;
    }

    public void handleClose() {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Panel Closed", "Policy Status Chart Panel has been closed.");
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

}

                       
