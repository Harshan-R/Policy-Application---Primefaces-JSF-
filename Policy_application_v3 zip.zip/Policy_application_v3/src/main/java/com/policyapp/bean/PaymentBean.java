package com.policyapp.bean;

import com.policyapp.dao.PaymentDao;
import com.policyapp.model.Payment;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
@Getter
@Setter
public class PaymentBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Payment> payments;
    private List<Payment> filteredPayments;
    private String searchBy;
    private String searchText;
    private PaymentDao paymentDao;

    @PostConstruct
    public void init() {
        paymentDao = new PaymentDao();
        try {
            payments = paymentDao.getAllPayments(); // Initialize with all payments
        } catch (SQLException e) {
            e.printStackTrace();
            payments = new ArrayList<>(); // Empty list or default behavior
        }
        filteredPayments = payments; // Initially, show all payments
    }

    public List<Payment> getPayments() {
		return payments;
	}

	public void setPayments(List<Payment> payments) {
		this.payments = payments;
	}

	public List<Payment> getFilteredPayments() {
		return filteredPayments;
	}

	public void setFilteredPayments(List<Payment> filteredPayments) {
		this.filteredPayments = filteredPayments;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public PaymentDao getPaymentDao() {
		return paymentDao;
	}

	public void setPaymentDao(PaymentDao paymentDao) {
		this.paymentDao = paymentDao;
	}

	public void searchPayments() {
        if (searchText == null || searchText.isEmpty()) {
            filteredPayments = payments; // Show all payments if search text is empty
            return;
        }

        try {
            switch (searchBy) {
                case "ID":
                    filteredPayments = paymentDao.getPaymentsById(Integer.parseInt(searchText));
                    break;
                case "policy_id":
                    filteredPayments = paymentDao.getPaymentsByPolicyId(Integer.parseInt(searchText));
                    break;
                case "bank_account_payer":
                    filteredPayments = paymentDao.getPaymentsByBankAccountPayer(searchText);
                    break;
                case "bank_account_payee":
                    filteredPayments = paymentDao.getPaymentsByBankAccountPayee(searchText);
                    break;
                default:
                    filteredPayments = payments; // Show all payments if search criteria is unknown
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            filteredPayments = payments; // Show all payments in case of error
        }
    }
}
