package com.policyapp.bean;

import com.policyapp.dao.AdminUserDAO;
import com.policyapp.model.AdminUser;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class AdminUserBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private AdminUserDAO adminUserDAO = new AdminUserDAO();
    private List<AdminUser> users;
    private List<AdminUser> filteredUsers;
    private AdminUser editingUser;
    //private AdminUser newUser;
    private int userId;
    private String username;
    private String email;
    
    private AdminUser newUser = new AdminUser();
    // Getter and Setter for newUser

    public AdminUser getNewUser() {
        return newUser;
    }

    public void setNewUser(AdminUser newUser) {
        this.newUser = newUser;
    }

    @PostConstruct
    public void init() {
        fetchUsers();
        editingUser = new AdminUser();
        newUser = new AdminUser(); // Initialize newUser for creation
    }

    public List<AdminUser> getUsers() {
        return users;
    }

    public List<AdminUser> getFilteredUsers() {
        return filteredUsers;
    }

    public AdminUser getEditingUser() {
        return editingUser;
    }

    public void setEditingUser(AdminUser editingUser) {
        this.editingUser = editingUser;
    }

//    public AdminUser getNewUser() {
//        return newUser;
//    }
//
//    public void setNewUser(AdminUser newUser) {
//        this.newUser = newUser;
//    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void fetchUsers() {
        try {
            users = adminUserDAO.getAllAdminUsers();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Failed to fetch users"));
        }
    }

    public void searchUsers() {
        try {
            users = adminUserDAO.searchUsers(userId, username, email);
            if (users.isEmpty()) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", "No users found"));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Failed to search users"));
        }
    }

    public void editUser(AdminUser user) {
        this.editingUser = user;
    }

    public void saveUser() {
        try {
            adminUserDAO.updateUserById(editingUser.getUserId(), editingUser.getUsername(), editingUser.getEmail(),
                    editingUser.getRole());
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "User details updated successfully"));
            fetchUsers(); // Refresh user list
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Failed to update user details"));
            //logger.log(Level.SEVERE, "Error saving user", e);
        }
    }



    public void deleteUser(String userId) {
        try {
            adminUserDAO.deleteUserById(userId); // Assuming deleteUser method in DAO accepts user ID
            fetchUsers(); // Refresh user list
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "User deleted successfully"));
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Failed to delete user"));
        }
    }

    public void createUser() {
        try {
            adminUserDAO.insertUser(newUser); // Insert the new user into the database
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "User created successfully"));
            fetchUsers(); // Refresh user list
            newUser = new AdminUser(); // Reset newUser after creation
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Failed to create user"));
        }
    }
}
