package com.policyapp.bean;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.policyapp.model.Claim;
import com.policyapp.model.Payment;
import com.policyapp.model.Policy;
import com.policyapp.model.User;
import com.policyapp.service.ClaimService;
import com.policyapp.service.PaymentService;
import com.policyapp.service.PolicyService;
import com.policyapp.service.UserService;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@ManagedBean
@ViewScoped
public class CustomerBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<Policy> policies;
	private Policy selectedPolicy;
	private Policy newPolicy;
	private String bankAccountPayer;
	private String customerEmail;
	private List<Policy> customerPolicies;

	private String searchEmail;
	private String password;

	public List<Policy> getCustomerPolicies() {
		return customerPolicies;
	}

	public void setCustomerPolicies(List<Policy> customerPolicies) {
		this.customerPolicies = customerPolicies;
	}

	@PostConstruct
	public void init() {
		// Initialize newPolicy here to avoid null pointer exception
		newPolicy = new Policy();

		// Load policies for the logged-in customer
		
	}

	public List<Policy> getPolicies() {
		return policies;
	}

	public Policy getSelectedPolicy() {
		return selectedPolicy;
	}

	public void setSelectedPolicy(Policy selectedPolicy) {
		this.selectedPolicy = selectedPolicy;
	}

	public Policy getNewPolicy() {
		return newPolicy;
	}

	public void setNewPolicy(Policy newPolicy) {
		this.newPolicy = newPolicy;
	}

	public String getBankAccountPayer() {
		return bankAccountPayer;
	}

	public void setBankAccountPayer(String bankAccountPayer) {
		this.bankAccountPayer = bankAccountPayer;
	}

	public void claimPolicy(Policy policy) {
		Claim claim = new Claim();
		claim.setPolicyId(policy.getId());
		claim.setClaimStatus("Pending");
		ClaimService.createClaim(claim);
	}

	public void submitNewPolicy() {
		try {
			if (newPolicy != null) {
				calculateCoveragePremium();
				PolicyService.createPolicy(newPolicy);
				init(); // Refresh the policy list
			} else {
				System.out.println("New policy object is null.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void makePayment() {
		if (selectedPolicy != null) {
			Payment payment = new Payment();
			payment.setPolicyId(selectedPolicy.getId());
			payment.setTotalPremiumAmount(selectedPolicy.getPremium());
			payment.setMonthlyPremium(selectedPolicy.getPremium());
			payment.setBankAccountPayer(bankAccountPayer);
			payment.setBankAccountPayee("MiltonLife@okhdfc");
			PaymentService.createPayment(payment);
		} else {
			System.out.println("Selected policy is null.");
		}
	}

	public void calculateCoveragePremium() {
		if (newPolicy != null) {
			// Calculate coverage and premium based on policy type and additional details
			double coverage = 0;
			double premium = 0;

			switch (newPolicy.getPolicyType()) {
			case "Auto":
				coverage = calculateAutoCoverage(newPolicy.getVehicleAge(), newPolicy.getAccidentHistory());
				premium = calculateAutoPremium(newPolicy.getVehicleAge(), newPolicy.getAccidentHistory());
				break;
			case "Home":
				coverage = calculateHomeCoverage(newPolicy.getHazardZone());
				premium = calculateHomePremium(newPolicy.getHazardZone());
				break;
			// Add more cases for other policy types
			case "Life":
				coverage = 400000;
				premium = 4200;
				break;

			case "Health":
				coverage = 100000;
				premium = 2200;
				break;

			case "Liability":
				coverage = 20000;
				premium = 1200;
				break;
			default:
				coverage = 35000;
				premium = 1400;
				break;

			}

			BigDecimal bdCoverage = BigDecimal.valueOf(coverage);
			BigDecimal bdPremium = BigDecimal.valueOf(premium);

			newPolicy.setCoverage(bdCoverage);
			System.out.println("Coverage and Premium is : " + bdCoverage + "     " + bdPremium);
			newPolicy.setPremium(bdPremium);
		} else {
			System.out.println("New policy object is null.");
		}
	}

	public double calculateAutoCoverage(int vehicleAge, boolean accidentHistory) {
		return 10000 - (vehicleAge * 500) - (accidentHistory ? 2000 : 0);
	}

	public double calculateAutoPremium(int vehicleAge, boolean accidentHistory) {
		return 1000 + (vehicleAge * 50) + (accidentHistory ? 200 : 0);
	}

	public double calculateHomeCoverage(boolean hazardZone) {
		return hazardZone ? 50000 : 100000;
	}

	public double calculateHomePremium(boolean hazardZone) {
		return hazardZone ? 1500 : 1000;
	}

	public String getLoggedInCustomerEmail() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		return (String) facesContext.getExternalContext().getSessionMap().get("userEmail");
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getSearchEmail() {
		return searchEmail;
	}

	public void setSearchEmail(String searchEmail) {
		this.searchEmail = searchEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	 public void searchPolicies() {
	        FacesMessage message;

	        // Validate email and password
	        if (!validateEmailAndPassword()) {
	            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid email or password", null);
	            FacesContext.getCurrentInstance().addMessage(null, message);
	            customerPolicies = null; // Clear policies list on invalid email or password
	            return;
	        }

	        // Retrieve policies for the searched email and password
	        customerPolicies = PolicyService.getPoliciesByEmail(searchEmail, password);

	        if (customerPolicies.isEmpty()) {
	            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "No policies found for the email and password", null);
	            FacesContext.getCurrentInstance().addMessage(null, message);
	        }
	    }

	    // Method to validate email and password
	    private boolean validateEmailAndPassword() {
	        // Retrieve password from PolicyService based on searchEmail
	        String retrievedPassword = PolicyService.getPasswordByEmail(searchEmail);

	        // Check if retrieved password matches input password
	        return retrievedPassword != null && retrievedPassword.equals(password);
	    }


}
