package com.policyapp.util;

import com.policyapp.model.Policy;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class PdfUtil {
    public static byte[] generatePolicyPdf(Policy policy) {
        return generatePolicyPdf(policy, null); // Defaulting to no signature
    }

    public static byte[] generatePolicyPdf(Policy policy, byte[] signature) {
        Document document = new Document();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        try {
            PdfWriter writer = PdfWriter.getInstance(document, baos);
            document.open();
            document.add(new Paragraph("Policy Details"));
            document.add(new Paragraph("Customer Name: " + policy.getCustomerName()));
            document.add(new Paragraph("Date of Birth: " + policy.getDob()));
            document.add(new Paragraph("Email: " + policy.getEmail()));
            document.add(new Paragraph("Phone: " + policy.getPhone()));
            document.add(new Paragraph("Policy Type: " + policy.getPolicyType()));
            document.add(new Paragraph("Coverage: " + policy.getCoverage()));
            document.add(new Paragraph("Premium: " + policy.getPremium()));
            document.add(new Paragraph("Start Date: " + policy.getPolicyStartDate()));
            document.add(new Paragraph("End Date: " + policy.getPolicyEndDate()));

            if (signature != null) {
                // Add the signature image to the PDF
                com.itextpdf.text.Image signatureImage = com.itextpdf.text.Image.getInstance(signature);
                document.add(signatureImage);
            }

            document.close();
            writer.close();
        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }

        return baos.toByteArray();
    }
}
