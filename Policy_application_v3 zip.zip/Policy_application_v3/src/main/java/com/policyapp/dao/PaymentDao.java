package com.policyapp.dao;

import com.policyapp.model.Payment;
import com.policyapp.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDao {

    public List<Payment> getAllPayments() throws SQLException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Payment payment = mapResultSetToPayment(resultSet);
                payments.add(payment);
            }
        }
        return payments;
    }

    public List<Payment> getPaymentsById(int id) throws SQLException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Payment payment = mapResultSetToPayment(resultSet);
                    payments.add(payment);
                }
            }
        }
        return payments;
    }

    public List<Payment> getPaymentsByPolicyId(int policyId) throws SQLException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE policy_id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, policyId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Payment payment = mapResultSetToPayment(resultSet);
                    payments.add(payment);
                }
            }
        }
        return payments;
    }

    public List<Payment> getPaymentsByBankAccountPayer(String bankAccountPayer) throws SQLException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE bank_account_payer = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bankAccountPayer);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Payment payment = mapResultSetToPayment(resultSet);
                    payments.add(payment);
                }
            }
        }
        return payments;
    }

    public List<Payment> getPaymentsByBankAccountPayee(String bankAccountPayee) throws SQLException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE bank_account_payee = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bankAccountPayee);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Payment payment = mapResultSetToPayment(resultSet);
                    payments.add(payment);
                }
            }
        }
        return payments;
    }

    private Payment mapResultSetToPayment(ResultSet resultSet) throws SQLException {
        Payment payment = new Payment();
        payment.setId(resultSet.getInt("id"));
        payment.setPolicyId(resultSet.getInt("policy_id"));
        payment.setTotalPremiumAmount(resultSet.getBigDecimal("total_premium_amount"));
        payment.setMonthlyPremium(resultSet.getBigDecimal("monthly_premium"));
        payment.setBankAccountPayer(resultSet.getString("bank_account_payer"));
        payment.setBankAccountPayee(resultSet.getString("bank_account_payee"));
        payment.setCreatedBy(resultSet.getInt("created_by"));
        payment.setCreatedDate(resultSet.getTimestamp("created_date"));
        payment.setUpdatedBy(resultSet.getInt("updated_by"));
        payment.setUpdatedDate(resultSet.getTimestamp("updated_date"));
        return payment;
    }
}
