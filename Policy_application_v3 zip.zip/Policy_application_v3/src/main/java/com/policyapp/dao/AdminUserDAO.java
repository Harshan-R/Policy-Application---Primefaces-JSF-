package com.policyapp.dao;

import com.policyapp.model.AdminUser;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdminUserDAO {

    private static final Logger logger = Logger.getLogger(AdminUserDAO.class.getName());

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/policy_app_11";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "password";

    private static final String GET_ALL_USERS_QUERY = "SELECT * FROM users";
    private static final String SEARCH_USERS_QUERY = "SELECT * FROM users WHERE 1=1";
    private static final String UPDATE_USER_QUERY = "UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?";
    private static final String DELETE_USER_QUERY = "DELETE FROM users WHERE id = ?";
    private static final String INSERT_USER_QUERY = "INSERT INTO users (id, username, email, role) VALUES (?, ?, ?, ?)";

    public List<AdminUser> getAllAdminUsers() {
        List<AdminUser> users = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(GET_ALL_USERS_QUERY);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                AdminUser user = new AdminUser();
                user.setUserId(rs.getString("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                users.add(user);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error fetching users", e);
        }
        return users;
    }

    public List<AdminUser> searchUsers(int userId, String username, String email) {
        List<AdminUser> users = new ArrayList<>();
        StringBuilder queryBuilder = new StringBuilder(SEARCH_USERS_QUERY);
        List<Object> params = new ArrayList<>();

        if (userId > 0) {
            queryBuilder.append(" AND id = ?");
            params.add(userId);
        }
        if (username != null && !username.isEmpty()) {
            queryBuilder.append(" AND username LIKE ?");
            params.add("%" + username + "%");
        }
        if (email != null && !email.isEmpty()) {
            queryBuilder.append(" AND email LIKE ?");
            params.add("%" + email + "%");
        }

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(queryBuilder.toString())) {

            int index = 1;
            for (Object param : params) {
                statement.setObject(index++, param);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    AdminUser user = new AdminUser();
                    user.setUserId(resultSet.getString("id"));
                    user.setUsername(resultSet.getString("username"));
                    user.setEmail(resultSet.getString("email"));
                    user.setRole(resultSet.getString("role"));
                    users.add(user);
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error searching users", e);
        }

        return users;
    }

    public void updateUserById(String userId, String username, String email, String role) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(UPDATE_USER_QUERY)) {

            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, role);
            stmt.setString(4, userId);
            
            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                logger.log(Level.INFO, "User with ID {0} updated successfully", userId);
            } else {
                logger.log(Level.WARNING, "No user updated for ID {0}", userId);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating user", e);
        }
    }



    public void deleteUserById(String userId) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(DELETE_USER_QUERY)) {

            stmt.setString(1, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error deleting user", e);
        }
    }

    public void insertUser(AdminUser user) {
        String query = "INSERT INTO users (id, username, email, role, password) VALUES (?, ?, ?, ?, ?)"; // Update this line

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(query)) {

            statement.setString(1, user.getUserId());
            statement.setString(2, user.getUsername());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getRole());
            statement.setString(5, user.getPassword()); // Add this line
            statement.executeUpdate();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error inserting user", e);
        }
    }

}
