package com.policyapp.dao;

import com.policyapp.model.Claim;
import com.policyapp.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDao {

    public List<Claim> getAllClaims() throws SQLException {
        List<Claim> claims = new ArrayList<>();
        String sql = "SELECT * FROM claims";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Claim claim = mapResultSetToClaim(resultSet);
                claims.add(claim);
            }
        }
        return claims;
    }

    public List<Claim> getClaimsById(int id) throws SQLException {
        List<Claim> claims = new ArrayList<>();
        String sql = "SELECT * FROM claims WHERE id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Claim claim = mapResultSetToClaim(resultSet);
                    claims.add(claim);
                }
            }
        }
        return claims;
    }

    public List<Claim> getClaimsByPolicyId(int policyId) throws SQLException {
        List<Claim> claims = new ArrayList<>();
        String sql = "SELECT * FROM claims WHERE policy_id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, policyId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Claim claim = mapResultSetToClaim(resultSet);
                    claims.add(claim);
                }
            }
        }
        return claims;
    }

    public List<Claim> getClaimsByStatus(String status) throws SQLException {
        List<Claim> claims = new ArrayList<>();
        String sql = "SELECT * FROM claims WHERE claim_status = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Claim claim = mapResultSetToClaim(resultSet);
                    claims.add(claim);
                }
            }
        }
        return claims;
    }

    private Claim mapResultSetToClaim(ResultSet resultSet) throws SQLException {
        Claim claim = new Claim();
        claim.setId(resultSet.getInt("id"));
        claim.setPolicyId(resultSet.getInt("policy_id"));
        claim.setClaimAmount(resultSet.getBigDecimal("claim_amount"));
        claim.setClaimDate(resultSet.getDate("claim_date"));
        claim.setResolutionDate(resultSet.getDate("resolution_date"));
        claim.setClaimStatus(resultSet.getString("claim_status"));
        claim.setPaymentMade(resultSet.getBoolean("payment_made"));
        claim.setCreatedBy(resultSet.getInt("created_by"));
        claim.setCreatedDate(resultSet.getTimestamp("created_date"));
        claim.setUpdatedBy(resultSet.getInt("updated_by"));
        claim.setUpdatedDate(resultSet.getTimestamp("updated_date"));
        return claim;
    }
}
