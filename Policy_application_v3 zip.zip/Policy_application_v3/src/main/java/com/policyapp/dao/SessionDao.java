package com.policyapp.dao;

import com.policyapp.model.Session;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SessionDao {
    private static final Logger logger = Logger.getLogger(SessionDao.class.getName());

    private final String jdbcURL = "jdbc:mysql://localhost:3306/policy_app_11";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "password";

    public List<Session> getAllSessions() {
        List<Session> sessions = new ArrayList<>();
        String query = "SELECT * FROM sessions";

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = conn.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Session session = new Session();
                session.setId(resultSet.getInt("id"));
                session.setUserId(resultSet.getInt("user_id"));
                session.setLoginTime(resultSet.getTimestamp("login_time"));
                session.setLogoutTime(resultSet.getTimestamp("logout_time"));
                sessions.add(session);
            }
        } catch (SQLException ex) {
            logger.log(Level.SEVERE, "Error fetching sessions", ex);
        }

        return sessions;
    }

    public List<Session> searchSessions(String searchBy, String searchText) {
        List<Session> sessions = new ArrayList<>();
        String query = buildQuery(searchBy);

        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = conn.prepareStatement(query)) {

            statement.setString(1, "%" + searchText + "%");
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Session session = new Session();
                session.setId(resultSet.getInt("id"));
                session.setUserId(resultSet.getInt("user_id"));
                session.setLoginTime(resultSet.getTimestamp("login_time"));
                session.setLogoutTime(resultSet.getTimestamp("logout_time"));
                sessions.add(session);
            }
        } catch (SQLException ex) {
            logger.log(Level.SEVERE, "Error searching sessions", ex);
        }

        return sessions;
    }

    private String buildQuery(String searchBy) {
        if (searchBy == null) {
            throw new IllegalArgumentException("Search criteria cannot be null");
        }

        switch (searchBy) {
            case "userId":
                return "SELECT * FROM sessions WHERE user_id LIKE ?";
            case "loginTime":
                return "SELECT * FROM sessions WHERE login_time LIKE ?";
            case "logoutTime":
                return "SELECT * FROM sessions WHERE logout_time LIKE ?";
            default:
                throw new IllegalArgumentException("Invalid search criteria");
        }
    }
}
