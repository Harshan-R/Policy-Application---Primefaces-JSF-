package com.policyapp.dao;

import com.policyapp.model.Policy;
import com.policyapp.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDao {

    public List<Policy> getAllPolicies() throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Policy policy = mapResultSetToPolicy(resultSet);
                policies.add(policy);
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesById(int id) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByCustomerName(String customerName) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE customer_name LIKE ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + customerName + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByType(String policyType) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE policy_type = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, policyType);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public List<Policy> getPoliciesByEmail(String email) throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE email LIKE ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + email + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Policy policy = mapResultSetToPolicy(resultSet);
                    policies.add(policy);
                }
            }
        }
        return policies;
    }

    public void createPolicy(Policy policy) {
        String sql = "INSERT INTO policies (customer_name, dob, medical_history, gender, " +
                     "address, email, phone, policy_type, policy_start_date, policy_end_date, " +
                     "coverage, premium, agent_approval, created_by, created_date, updated_by, updated_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, policy.getCustomerName());
            statement.setDate(2, new java.sql.Date(policy.getDob().getTime()));
            statement.setBoolean(3, policy.isMedicalHistory());
            statement.setString(4, policy.getGender());
            statement.setString(5, policy.getAddress());
            statement.setString(6, policy.getEmail());
            statement.setString(7, policy.getPhone());
            statement.setString(8, policy.getPolicyType());
            statement.setDate(9, new java.sql.Date(policy.getPolicyStartDate().getTime()));
            statement.setDate(10, new java.sql.Date(policy.getPolicyEndDate().getTime()));
            statement.setBigDecimal(11, policy.getCoverage());
            statement.setBigDecimal(12, policy.getPremium());
            statement.setString(13, policy.getAgentApproval());
            statement.setInt(14, policy.getCreatedBy());
            statement.setDate(15, new java.sql.Date(policy.getCreatedDate().getTime()));
            statement.setInt(16, policy.getUpdatedBy());
            statement.setDate(17, new java.sql.Date(policy.getUpdatedDate().getTime()));

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating policy failed, no rows affected.");
            }

            // Retrieve the auto-generated keys (policy ID)
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    policy.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating policy failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception appropriately, e.g., log, throw custom exception, etc.
        }
    }

    private Policy mapResultSetToPolicy(ResultSet resultSet) throws SQLException {
        Policy policy = new Policy();
        policy.setId(resultSet.getInt("id"));
        policy.setCustomerName(resultSet.getString("customer_name"));
        policy.setDob(resultSet.getDate("dob"));
        policy.setMedicalHistory(resultSet.getBoolean("medical_history"));
        policy.setGender(resultSet.getString("gender"));
        policy.setAddress(resultSet.getString("address"));
        policy.setEmail(resultSet.getString("email"));
        policy.setPhone(resultSet.getString("phone"));
        policy.setPolicyType(resultSet.getString("policy_type"));
        policy.setPolicyStartDate(resultSet.getDate("policy_start_date"));
        policy.setPolicyEndDate(resultSet.getDate("policy_end_date"));
        policy.setCoverage(resultSet.getBigDecimal("coverage"));
        policy.setPremium(resultSet.getBigDecimal("premium"));
        policy.setAgentApproval(resultSet.getString("agent_approval"));
        policy.setCreatedBy(resultSet.getInt("created_by"));
        policy.setCreatedDate(resultSet.getDate("created_date"));
        policy.setUpdatedBy(resultSet.getInt("updated_by"));
        policy.setUpdatedDate(resultSet.getDate("updated_date"));
        return policy;
    }
}
