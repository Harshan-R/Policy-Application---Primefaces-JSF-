package com.policyapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.policyapp.model.Payment;
import com.policyapp.util.DatabaseUtil;

public class PaymentService {
    public static void createPayment(Payment payment) {
        String sql = "INSERT INTO payments (policy_id, total_premium_amount, monthly_premium, bank_account_payer, bank_account_payee, created_by) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, payment.getPolicyId());
            ps.setBigDecimal(2, payment.getTotalPremiumAmount());
            ps.setBigDecimal(3, payment.getMonthlyPremium());
            ps.setString(4, payment.getBankAccountPayer());
            ps.setString(5, payment.getBankAccountPayee());
            ps.setInt(6, payment.getCreatedBy());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

