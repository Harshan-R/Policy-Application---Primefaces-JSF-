package com.policyapp.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import com.policyapp.model.Claim;
import com.policyapp.util.DatabaseUtil;

public class ClaimService {
    public static void createClaim(Claim claim) {
        String sql = "INSERT INTO claims (policy_id, claim_amount, claim_date, claim_status, payment_made, created_by) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, claim.getPolicyId());
            ps.setBigDecimal(2, claim.getClaimAmount());
            ps.setDate(3, Date.valueOf(LocalDate.now()));
            ps.setString(4, claim.getClaimStatus());
            ps.setBoolean(5, claim.isPaymentMade());
            ps.setInt(6, claim.getCreatedBy());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

