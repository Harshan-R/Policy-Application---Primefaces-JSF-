package com.policyapp.service;

import com.policyapp.model.Policy;
import com.policyapp.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class PolicyService {

	public static void createPolicy(Policy policy) {
	    String sql = "INSERT INTO policies (customer_name, dob, medical_history, gender, address, email, phone, policy_type, policy_start_date, policy_end_date, coverage, premium, agent_approval, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	    try (Connection connection = DatabaseUtil.getConnection();
	         PreparedStatement ps = connection.prepareStatement(sql)) {
	        ps.setString(1, policy.getCustomerName());
	        
	        // Null check for dob
	        if (policy.getDob() != null) {
	            ps.setDate(2, new java.sql.Date(policy.getDob().getTime()));
	        } else {
	        	ps.setDate(2, Date.valueOf(LocalDate.now())); // or handle it as appropriate for your database schema
	        }
	        
	        ps.setBoolean(3, policy.isMedicalHistory());
	        ps.setString(4, policy.getGender());
	        ps.setString(5, policy.getAddress());
	        ps.setString(6, policy.getEmail());
	        ps.setString(7, policy.getPhone());
	        ps.setString(8, policy.getPolicyType());
	        ps.setDate(9, Date.valueOf(LocalDate.now()));
	        LocalDate today = LocalDate.now();
            LocalDate oneYearLater = today.plusYears(1);
            ps.setDate(10, Date.valueOf(oneYearLater));
	        ps.setBigDecimal(11, policy.getCoverage());
	        ps.setBigDecimal(12, policy.getPremium());
	        ps.setString(13, policy.getAgentApproval());
	        ps.setInt(14, policy.getCreatedBy());
	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle SQLException properly, log it or throw a custom exception
	    }
	}


//    public static List<Policy> getPoliciesByEmail(String email) {
//        List<Policy> policies = new ArrayList<>();
//        String sql = "SELECT * FROM policies WHERE email = ?";
//        try (Connection connection = DatabaseUtil.getConnection();
//             PreparedStatement ps = connection.prepareStatement(sql)) {
//            ps.setString(1, email);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                Policy policy = new Policy();
//                policy.setId(rs.getInt("id"));
//                policy.setCustomerName(rs.getString("customer_name"));
//                policy.setDob(rs.getDate("dob"));
//                policy.setMedicalHistory(rs.getBoolean("medical_history"));
//                policy.setGender(rs.getString("gender"));
//                policy.setAddress(rs.getString("address"));
//                policy.setEmail(rs.getString("email"));
//                policy.setPhone(rs.getString("phone"));
//                policy.setPolicyType(rs.getString("policy_type"));
//                policy.setPolicyStartDate(rs.getDate("policy_start_date"));
//                policy.setPolicyEndDate(rs.getDate("policy_end_date"));
//                policy.setCoverage(rs.getBigDecimal("coverage"));
//                policy.setPremium(rs.getBigDecimal("premium"));
//                policy.setAgentApproval(rs.getString("agent_approval"));
//                policies.add(policy);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            // Handle SQLException properly, log it or throw a custom exception
//        }
//        return policies;
//    }
	
	public static List<Policy> getPoliciesByEmail(String email,String password) {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies WHERE email = ? AND EXISTS (SELECT 1 FROM users WHERE email = ? AND password = ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, email);
            ps.setString(3, getPasswordByEmail(email)); // Assuming you have a method to get password by email
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Policy policy = new Policy();
                policy.setId(rs.getInt("id"));
                policy.setCustomerName(rs.getString("customer_name"));
                policy.setDob(rs.getDate("dob"));
                policy.setMedicalHistory(rs.getBoolean("medical_history"));
                policy.setGender(rs.getString("gender"));
                policy.setAddress(rs.getString("address"));
                policy.setEmail(rs.getString("email"));
                policy.setPhone(rs.getString("phone"));
                policy.setPolicyType(rs.getString("policy_type"));
                policy.setPolicyStartDate(rs.getDate("policy_start_date"));
                policy.setPolicyEndDate(rs.getDate("policy_end_date"));
                policy.setCoverage(rs.getBigDecimal("coverage"));
                policy.setPremium(rs.getBigDecimal("premium"));
                policy.setAgentApproval(rs.getString("agent_approval"));
                policies.add(policy);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException properly, log it or throw a custom exception
        }
        return policies;
    }

	public static String getPasswordByEmail(String email) {
        String password = null;
        String sql = "SELECT password FROM users WHERE email = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                password = rs.getString("password");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException properly, log it or throw a custom exception
        }
        
        return password;
    }
}
