package com.policyapp.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Session implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private int userId;
    private Timestamp loginTime;
    private Timestamp logoutTime;

    // Getters and Setters for all fields

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Timestamp getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Timestamp loginTime) {
        this.loginTime = loginTime;
    }

    public Timestamp getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(Timestamp logoutTime) {
        this.logoutTime = logoutTime;
    }
}
