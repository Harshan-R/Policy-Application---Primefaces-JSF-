package com.policyapp.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class Policy implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String customerName;
    private Date dob;
    private boolean medicalHistory;
    private String gender;
    private String address;
    private String email;
    private String phone;
    private String policyType;
    private Date policyStartDate;
    private Date policyEndDate;
    private BigDecimal coverage;
    private BigDecimal premium;
    private String agentApproval;
    private int createdBy;
    private Date createdDate;
    private int updatedBy;
    private Date updatedDate;

    // Additional fields for specific policy types
    private String vehicleModel;
    private int vehicleYear;

    // Life/Health specific fields
    private boolean disability;
    private boolean surgeryHistory;
    private boolean smokingHabit;
    private boolean drinksHabit;

    // Home specific fields
    private String buildingType;
    private int distanceToCoast;
    private boolean facedNaturalCalamity;
    private boolean secureElectricalSupply;

	private Date signatureTimestamp;
	
	
	//private String agentApproval;
    private Integer vehicleAge;  // New field for Auto policy
    private Boolean accidentHistory;  // New field for Auto policy
    private Boolean hazardZone; 

    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public boolean isMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(boolean medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public Date getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public Date getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(Date policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public BigDecimal getCoverage() {
		return coverage;
	}

	public void setCoverage(BigDecimal coverage) {
		this.coverage = coverage;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	public String getAgentApproval() {
		return agentApproval;
	}

	public void setAgentApproval(String agentApproval) {
		this.agentApproval = agentApproval;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	
    // Getters and Setters for additional fields

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public int getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(int vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public boolean isDisability() {
        return disability;
    }

    public void setDisability(boolean disability) {
        this.disability = disability;
    }

    public boolean isSurgeryHistory() {
        return surgeryHistory;
    }

    public void setSurgeryHistory(boolean surgeryHistory) {
        this.surgeryHistory = surgeryHistory;
    }

    public boolean isSmokingHabit() {
        return smokingHabit;
    }

    public void setSmokingHabit(boolean smokingHabit) {
        this.smokingHabit = smokingHabit;
    }

    public boolean isDrinksHabit() {
        return drinksHabit;
    }

    public void setDrinksHabit(boolean drinksHabit) {
        this.drinksHabit = drinksHabit;
    }

    public String getBuildingType() {
        return buildingType;
    }

    public void setBuildingType(String buildingType) {
        this.buildingType = buildingType;
    }

    public int getDistanceToCoast() {
        return distanceToCoast;
    }

    public void setDistanceToCoast(int distanceToCoast) {
        this.distanceToCoast = distanceToCoast;
    }

    public boolean isFacedNaturalCalamity() {
        return facedNaturalCalamity;
    }

    public void setFacedNaturalCalamity(boolean facedNaturalCalamity) {
        this.facedNaturalCalamity = facedNaturalCalamity;
    }

    public boolean isSecureElectricalSupply() {
        return secureElectricalSupply;
    }

    public void setSecureElectricalSupply(boolean secureElectricalSupply) {
        this.secureElectricalSupply = secureElectricalSupply;
    }

	public Integer getVehicleAge() {
		return vehicleAge;
	}

	public void setVehicleAge(Integer vehicleAge) {
		this.vehicleAge = vehicleAge;
	}

	public Boolean getAccidentHistory() {
		return accidentHistory;
	}

	public void setAccidentHistory(Boolean accidentHistory) {
		this.accidentHistory = accidentHistory;
	}

	public Boolean getHazardZone() {
		return hazardZone;
	}

	public void setHazardZone(Boolean hazardZone) {
		this.hazardZone = hazardZone;
	}

	public void setSignatureTimestamp(Date date) {
		this.signatureTimestamp = date;
		
	}
}
