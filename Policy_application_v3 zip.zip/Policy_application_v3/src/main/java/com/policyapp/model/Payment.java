package com.policyapp.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
public class Payment {

    private int id;
    private int policyId;
    private BigDecimal totalPremiumAmount;
    private BigDecimal monthlyPremium;
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public BigDecimal getTotalPremiumAmount() {
		return totalPremiumAmount;
	}
	public void setTotalPremiumAmount(BigDecimal totalPremiumAmount) {
		this.totalPremiumAmount = totalPremiumAmount;
	}
	public BigDecimal getMonthlyPremium() {
		return monthlyPremium;
	}
	public void setMonthlyPremium(BigDecimal monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}
	public String getBankAccountPayer() {
		return bankAccountPayer;
	}
	public void setBankAccountPayer(String bankAccountPayer) {
		this.bankAccountPayer = bankAccountPayer;
	}
	public String getBankAccountPayee() {
		return bankAccountPayee;
	}
	public void setBankAccountPayee(String bankAccountPayee) {
		this.bankAccountPayee = bankAccountPayee;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	private String bankAccountPayer;
    private String bankAccountPayee;
    private int createdBy;
    private Timestamp createdDate;
    private int updatedBy;
    private Timestamp updatedDate;
}
